package services;

import models.Article;

import java.util.Arrays;
import java.util.List;

import java.util.*;
import models.Article;

public class ArticleService {
    public List<Article> initialiserArticles() {
        return Arrays.asList(
            new Article(1, "tissu-lin"),
            new Article(2, "tissu-coton"),
            new Article(3, "broderie"),
            new Article(4, "getzner"),
            new Article(5, "voile"),
            new Article(6, "fils"),
            new Article(7, "laine"),
            new Article(8, "Gravier"),
            new Article(9, "Ciment"),
            new Article(10, "Fer"),
            new Article(11, "Brique"),
            new Article(12, "Plâtre")

        );
    }
}
