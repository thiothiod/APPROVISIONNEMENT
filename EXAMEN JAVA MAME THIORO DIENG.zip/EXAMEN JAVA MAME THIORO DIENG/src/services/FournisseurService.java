package services;
import models.Fournisseur;

import java.util.Arrays;
import java.util.List;

import java.util.Arrays;
import java.util.List;
import models.Fournisseur;

public class FournisseurService {
    public List<Fournisseur> initialiserFournisseurs() {
        return Arrays.asList(
            new Fournisseur(1, "Papeterie Dakar"),
            new Fournisseur(2, "Fournitures Express"),
            new Fournisseur(3, "Thioro textiles"),
            new Fournisseur(4, "Quincaillerie d' Afrique"),
            new Fournisseur(5, "Fournitures Générales")
        
            // Ajoutez d'autres fournisseurs si nécessaire

        );
    }
}
