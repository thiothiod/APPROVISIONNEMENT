
package services;
import models.Approvisionnement;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ApprovisionnementService {
    private List<Approvisionnement> approvisionnements = new ArrayList<>();

    public void enregistrerApprovisionnement(Approvisionnement approv) {
        approvisionnements.add(approv);
    }

    public List<Approvisionnement> listerApprovisionnements() {
        return approvisionnements;
    }

    public List<Approvisionnement> filtrerParPeriode(LocalDate debut, LocalDate fin) {
        return approvisionnements.stream()
                .filter(a -> (a.getDate().isEqual(debut) || a.getDate().isAfter(debut)) &&
                             (a.getDate().isEqual(fin) || a.getDate().isBefore(fin)))
                .collect(Collectors.toList());
    }
}
