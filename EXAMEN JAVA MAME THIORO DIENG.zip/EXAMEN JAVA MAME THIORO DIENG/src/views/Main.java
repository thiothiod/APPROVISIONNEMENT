package views;

import models.*;
import services.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ArticleService articleService = new ArticleService();
        FournisseurService fournisseurService = new FournisseurService();
        ApprovisionnementService approvService = new ApprovisionnementService();
        List<Article> articles = articleService.initialiserArticles();
        List<Fournisseur> fournisseurs = fournisseurService.initialiserFournisseurs();
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("\n=== MENU ===");
            System.out.println("1. Enregistrer un approvisionnement");
            System.out.println("2. Lister les approvisionnements");
            System.out.println("3. Filtrer les approvisionnements par période");
            System.out.println("0. Quitter");
            System.out.print("Votre choix : ");
            int choix = scanner.nextInt();
            scanner.nextLine();
            switch (choix) {
                case 1:
                    System.out.print("Référence de l'approvisionnement : ");
                    String ref = scanner.nextLine();
                    System.out.println("Choisir un fournisseur :");
                    for (int i = 0; i < fournisseurs.size(); i++) {
                        System.out.println((i+1) + ". " + fournisseurs.get(i).getNom());
                    }
                    int idxF = scanner.nextInt() - 1;
                    scanner.nextLine();
                    Fournisseur f = fournisseurs.get(idxF);
                    Approvisionnement approv = new Approvisionnement(ref, LocalDate.now(), f);
                    while (true) {
                        System.out.println("Ajouter un article (0 pour arrêter) :");
                        for (int i = 0; i < articles.size(); i++) {
                            System.out.println((i+1) + ". " + articles.get(i).getNom());
                        }
                        int idxA = scanner.nextInt();
                        if (idxA == 0) break;
                        Article art = articles.get(idxA-1);
                        System.out.print("Quantité : ");
                        int qte = scanner.nextInt();
                        System.out.print("Prix unitaire : ");
                        double pu = scanner.nextDouble();
                        scanner.nextLine();
                        approv.ajouterArticle(new ApprovisionnementArticle(art, qte, pu));
                    }
                    if (approv.getArticles().size() > 0) {
                        approvService.enregistrerApprovisionnement(approv);
                        System.out.println("Approvisionnement enregistré !");
                    } else {
                        System.out.println("Aucun article ajouté. Approvisionnement non enregistré.");
                    }
                    break;
                case 2:
                    System.out.println("\n📦 Liste détaillée des approvisionnements :");
                    for (Approvisionnement a : approvService.listerApprovisionnements()) {
                        System.out.println("Référence : " + a.getReference());
                        System.out.println("Date : " + a.getDate());
                        System.out.println("Fournisseur : " + a.getFournisseur().getNom());
                        System.out.println("Montant total : " + a.getMontantTotal() + " FCFA");
                        System.out.println("Articles :");
                        for (ApprovisionnementArticle aa : a.getArticles()) {
                            System.out.println("  - " + aa.getArticle().getNom() + " | Qté : " + aa.getQuantite() + " | PU : " + aa.getPrixUnitaire());
                        }
                        System.out.println("-----------------------------");
                    }
                    break;
                case 3:
                    System.out.print("Date début (yyyy-mm-dd) : ");
                    String d1 = scanner.nextLine();
                    System.out.print("Date fin (yyyy-mm-dd) : ");
                    String d2 = scanner.nextLine();
                    LocalDate debut = LocalDate.parse(d1);
                    LocalDate fin = LocalDate.parse(d2);
                    List<Approvisionnement> filtres = approvService.filtrerParPeriode(debut, fin);
                    System.out.println("\n🔍 Filtrés entre " + debut + " et " + fin + ": " + filtres.size() + " trouvé(s)");
                    for (Approvisionnement a : filtres) {
                        System.out.println("- " + a.getReference() + " | " + a.getDate() + " | " + a.getMontantTotal() + " FCFA");
                    }
                    break;
                case 0:
                    System.out.println("Au revoir !");
                    return;
                default:
                    System.out.println("Choix invalide.");
            }
        }
    }
}
