package models;

public class ApprovisionnementArticle {
    private Article article;
    private int quantite;
    private double prixUnitaire;

    public ApprovisionnementArticle(Article article, int quantite, double prixUnitaire) {
        this.article = article;
        this.quantite = quantite;
        this.prixUnitaire = prixUnitaire;
    }

    public double getMontant() {
        return quantite * prixUnitaire;
    }

    public Article getArticle() { return article; }
    public int getQuantite() { return quantite; }
    public double getPrixUnitaire() { return prixUnitaire; }
}