package models;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Approvisionnement {
    private String reference;
    private LocalDate date;
    private Fournisseur fournisseur;
    private List<ApprovisionnementArticle> articles = new ArrayList<>();

    public Approvisionnement(String reference, LocalDate date, Fournisseur fournisseur) {
        this.reference = reference;
        this.date = date;
        this.fournisseur = fournisseur;
    }

    public void ajouterArticle(ApprovisionnementArticle article) {
        articles.add(article);
    }

    public double getMontantTotal() {
        return articles.stream().mapToDouble(ApprovisionnementArticle::getMontant).sum();
    }

    public String getReference() { return reference; }
    public LocalDate getDate() { return date; }
    public Fournisseur getFournisseur() { return fournisseur; }
    public List<ApprovisionnementArticle> getArticles() { return articles; }
}
